package com.capgemini.tcc.bean;

import java.util.Date;

public class PatientBean 
{
   
	private int patient_id;
    private String patient_name;
    private String age;
    private String phone;
    private String description;
    private Date consultDate;
	public int getPatient_id() 
	{
		return patient_id;
	}
	public void setPatient_id(int patient_id) 
	{
		this.patient_id = patient_id;
	}
	public String getPatient_name() 
	{
		return patient_name;
	}
	public void setPatient_name(String patient_name) 
	{
		this.patient_name = patient_name;
	}
	public String getAge() 
	{
		return age;
	}
	public void setAge(String age)
	{
		this.age = age;
	}
	public String getPhone() 
	{
		return phone;
	}
	public void setPhone(String phone) 
	{
		this.phone = phone;
	}
	public String getDescription()
	{
		return description;
	}
	public void setDescription(String description) 
	{
		this.description = description;
	}
	
	public Date getConsultDate() 
	{
		return consultDate;
	}
	public void setConsultDate(Date consultDate) 
	{
		this.consultDate = consultDate;
	}
	
	 @Override
		public String toString()
	 {
		 StringBuilder sb = new StringBuilder();
			sb.append("Printing Patient Details \n");
			sb.append("Patient ID: " +patient_id +"\n");
			sb.append("Patient Name: "+ patient_name +"\n");
			sb.append("Age: "+ age +"\n");
			sb.append("Phone: "+ phone +"\n");
			sb.append("Description: "+ description);
			sb.append("Consultation date: "+ consultDate);
			return sb.toString();
	 }
}
