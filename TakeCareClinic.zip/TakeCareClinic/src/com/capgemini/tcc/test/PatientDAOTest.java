package com.capgemini.tcc.test;

import static org.junit.Assert.*;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exception.PatientException;


public class PatientDAOTest {

	static PatientDAO dao;
	static PatientBean patient;

	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new PatientDAO();
		patient = new PatientBean();
	}

	@Test
	public void testAddDonarDetails() throws PatientException {

		assertNotNull(dao.addPatientDetails(patient));

	}

	/************************************
	 * Test case for addDonarDetails()
	 * 
	 ************************************/

	@Ignore
	@Test
	public void testAddDonarDetails1() throws PatientException {
		// increment the number next time you test for positive test case
		assertEquals(1001, dao.addPatientDetails(patient));
	}

	/************************************
	 * Test case for addDonarDetails()
	 * 
	 ************************************/

	@Test
	public void testAddDonarDetails2() throws PatientException {

		patient.setPatient_name("Allen");
		patient.setAge("21");
		patient.setPhone("9876543210");
		patient.setDescription("fever");
		assertEquals(1001, dao.addPatientDetails(patient));
		/*assertTrue("Data Inserted successfully",
				Integer.parseInt(dao.addDonorDetails(donor)) > 1000);*/

	}

	
	/****************************************************
	 * Test case for viewById()
	 ******************************************************/

	@Test
	public void testById() throws PatientException {
		assertNotNull(dao.getPatientDetails(1001));
	}

	@Ignore
	@Test
	public void testById1() throws PatientException {
		assertEquals("TestName", dao.getPatientDetails(1001).getPatient_name());
	}

}
