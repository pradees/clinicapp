package com.capgemini.tcc.ui;
import java.util.InputMismatchException;
import java.util.Scanner;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.tcc.service.IPatientService;
import com.capgemini.tcc.service.PatientService;;
public class Client 
{

	static Scanner sc = new Scanner(System.in);
	static IPatientService patientService = null;
	static PatientService patientServiceImpl = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) 
	{
		PropertyConfigurator.configure("resources//log4j.properties");
		PatientBean patientBean = null;

		int option = 0;

		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("   TAKECARE CLINIC ");
			System.out.println("_______________________________\n");

			System.out.println("1.Add Patient Information");
			System.out.println("2.Search Patient by Id");
			System.out.println("3.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try {
				option = sc.nextInt();

				int patientId;
				switch (option) {

				case 1:

					while (patientBean == null) {
						patientBean = populatePatientBean();
						// System.out.println(donorBean);
					}

					try {
						patientService = new PatientService();
						patientId = patientService.addPatientDetails(patientBean);

						System.out.println("Patient details  has been successfully registered ");
						System.out.println("Patient ID Is: " + patientId);

					} catch (PatientException patientException) {
						logger.error("exception occured", patientException);
						System.err.println("ERROR : "+ patientException.getMessage());
					} finally {
						patientId = 0;
						patientService = null;
						patientBean = null;
					}

					break;

				case 2:

					patientServiceImpl = new PatientService();

					System.out.println("Enter numeric donor id:");
					patientId = sc.nextInt();

					while (true) 
					{
						if (patientServiceImpl.validatePatientId(Integer.toString(patientId))) 
						{
							break;
						} else {
							System.err
									.println("Please enter numeric patient id only, try again");
							patientId = sc.nextInt();
						}
					}

					patientBean = getPatientDetails(patientId);

					if (patientBean != null) {
						System.out.println("Name: "
								+ patientBean.getPatient_name());
						System.out.println("Age: "
								+ patientBean.getAge());
						System.out.println("Phone Number: "
								+ patientBean.getPhone());
						System.out.println("Description: "
								+ patientBean.getDescription());
						System.out.println("Consult Date: "
								+ patientBean.getConsultDate());
					} else {
						System.err
								.println("There are no patient details associated with patient id "
										+ patientId);
					}

					break;

				case 3:

					System.out.print("Exit Patient Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
				}// end of switch
			}

			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}

		}// end of while
	}// end of try

	/*
	 * This function will call the service layer method and return the bean
	 * object which is populated by the information of the given donorId in
	 * parameter
	 */
	private static PatientBean getPatientDetails(int patientId) {
		PatientBean patientBean = null;
		patientService = new PatientService();

		try {
			patientBean = patientService.getPatientDetails(patientId);
		} catch (PatientException patientException) {
			logger.error("exception occured ", patientException);
			System.out.println("ERROR : " + patientException.getMessage());
		}

		patientService = null;
		return patientBean;
	}

	/*
	 * This function will be called by main and will return a validated bean
	 * object OR null if details are invalid
	 */
	private static PatientBean populatePatientBean() {

		// Reading and setting the values for the donorBean
		
		PatientBean patientBean = new PatientBean();;

		System.out.println("\n Enter Details");

		System.out.println("Enter the name of the Patient:");
		patientBean.setPatient_name(sc.next());

		System.out.println("Enter Patient Age:");
		patientBean.setAge(sc.next());

		System.out.println("Enter Patient phone number:");
		patientBean.setPhone(sc.next());

		System.out.println("Enter Description:");
		patientBean.setDescription(sc.next());

		patientServiceImpl = new PatientService();

		try {
			patientServiceImpl.validatePatient(patientBean);
			return patientBean;
		} catch (PatientException patientException) {
			logger.error("exception occured", patientException);
			System.err.println("Invalid data:");
			System.err.println(patientException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return null;
	
	
		

	}

}
