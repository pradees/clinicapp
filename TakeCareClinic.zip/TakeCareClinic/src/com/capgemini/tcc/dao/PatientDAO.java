package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.tcc.util.CommonCon;

public class PatientDAO implements IPatientDAO
{
	
	Logger logger=Logger.getRootLogger();
	public PatientDAO()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}


	public int addPatientDetails(PatientBean patient) throws PatientException 
	{
		Connection connection = CommonCon.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		int patientId=0;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			preparedStatement.setString(1,patient.getPatient_name());			
			preparedStatement.setString(2,patient.getAge());
			preparedStatement.setString(3,patient.getPhone());
			preparedStatement.setString(4,patient.getDescription());			
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.PATIENTID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			
			if(resultSet.next())
			{
				patientId=resultSet.getInt(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new PatientException("Inserting patient details failed ");

			}
			else
			{
				logger.info("Patient details added successfully:");
				return patientId;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new PatientException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new PatientException("Error in closing db connection");

			}
		}
		
		
	}

	
	public PatientBean getPatientDetails(int patientId) throws PatientException
	{
		
		Connection connection=CommonCon.getInstance().getConnection();
		
		
		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
		PatientBean bean=null;
		
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.VIEW_PATIENT_DETAILS_QUERY);
			preparedStatement.setInt(1,patientId);
			resultset=preparedStatement.executeQuery();
			
			if(resultset.next())
			{
				bean = new PatientBean();
				bean.setPatient_name(resultset.getString(1));
				bean.setAge(resultset.getString(2));
				bean.setPhone(resultset.getString(3));
				bean.setDescription(resultset.getString(4));
				bean.setConsultDate(resultset.getDate(5));
				
			}
			
			if( bean != null)
			{
				logger.info("Record Found Successfully");
				return bean;
			}
			else
			{
				logger.info("Record Not Found Successfully");
				return null;
			}
			
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
			throw new PatientException(e.getMessage());
		}
		finally
		{
			try 
			{
				//resultset.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new PatientException("Error in closing db connection");

			}
		}
		
	}
}


