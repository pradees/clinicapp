package com.capgemini.tcc.dao;

public interface QueryMapper 
{
	
	
	public static final String VIEW_PATIENT_DETAILS_QUERY="SELECT patient_name,age,phone,description,consultation_date FROM Patient WHERE  patient_id=?";
	public static final String INSERT_QUERY="INSERT INTO Patient VALUES(Patient_Id_sequence.NEXTVAL,?,?,?,?,SYSDATE)";
	public static final String PATIENTID_QUERY_SEQUENCE="SELECT Patient_Id_sequence.CURRVAL FROM DUAL";
	
	
}
