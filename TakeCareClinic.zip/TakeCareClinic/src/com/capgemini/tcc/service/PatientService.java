package com.capgemini.tcc.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.IPatientDAO;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exception.PatientException;

public class PatientService  implements IPatientService
{
IPatientDAO patientDao;
	
	public int addPatientDetails(PatientBean patient) throws PatientException 
{
		patientDao=new PatientDAO();	
		int patientSeq;
		patientSeq= patientDao.addPatientDetails(patient);
		return patientSeq; 
	}

	public PatientBean getPatientDetails(int patientId) throws PatientException 
	{
		patientDao=new PatientDAO();
		PatientBean bean=null;
		bean=patientDao.getPatientDetails(patientId);
		return bean;
	}
	
	public void validatePatient(PatientBean bean) throws PatientException
	{
		List<String> validationErrors = new ArrayList<String>();

		//Validating patient name
		if(!(isValidName(bean.getPatient_name()))) {
			validationErrors.add("\n Patient Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		
		//Validating Phone Number
		if(!(isValidPhoneNumber(bean.getPhone()))){
			validationErrors.add("\n Phone Number Should be in 10 digit \n");
		}
				
		if(!validationErrors.isEmpty())
			throw new PatientException(validationErrors +"");
	}

	public boolean isValidName(String patientName){
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(patientName);
		return nameMatcher.matches();
	}
		
	public boolean isValidPhoneNumber(String phoneNumber){
		Pattern phonePattern=Pattern.compile("^[6-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(phoneNumber);
		return phoneMatcher.matches();
		
	}

	public boolean validatePatientId(String patientId)
	{
		
		Pattern idPattern = Pattern.compile("[0-9]{1,4}");
		Matcher idMatcher = idPattern.matcher(patientId);
		
		if(idMatcher.matches())
			return true;
		else
			return false;		
	}

	
}
